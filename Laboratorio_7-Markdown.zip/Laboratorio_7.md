# Laboratorio 7: Analisis de Redes Sociales

* Jose Jo 14343
* Eric Mendoza 15002
* Marlon Fuentes 15240
---

### Introducción 

En el siguiente reporte se presenta los resultados obtenidos al análisar las opiniones de las personas acerca del tráfico en Guatemala. Para este estudio se útilizo twitter como fuente de obtención de data. 


### 1. Preparación de Entorno

**1.1 Carga de Librerias**


```python
import tweepy as tw
import re
from nltk.corpus import stopwords
from collections import Counter
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from wordcloud import WordCloud
```

**1.2 Conexión de API**


```python
#credenciales de twitter
consumer_key = '7luA64Oj8agDpvB4xwHPhFFP7'
consumer_secret = 'cq4xThEXUYNbFi6s3xcKYuHIdZHGOW0GpA54dlwwwajGq3vl9l'
access_key= '3009764083-P128RjXECZSZGo6i56YD9nR4INiwbSTEzJErHJt'
access_secret = 'F86Wxm9qi3bvBm8UbL9wuzNKmTOsPG4WxbRZ1osFbQEQ6'

#Conexion utilizando tweepy
auth = tw.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_key, access_secret)
api = tw.API(auth)
```

### 2. Problema 2: Temblores en Guatemala


**2.1 Obtencion de la data**


```python
#agregar termino de busqueda, eliminar retuits y realizar busqueda en Guatemala


search_terms="#TraficoGT OR #TransitoGT"+" -filter:retweets"




tweets=tw.Cursor(api.search,q=search_terms).items()

traffic_list=[tweet.text for tweet in tweets]
print(len(quake_list))

def sample_printer(text):
  for i in range(0,10):
    print(text[i])
  

```

    781
    

**2.2 Limpieza de Datos**

- Estandarización del texto 
  - Conversión a minúsculas


```python
#lista original
sample_printer(traffic_list)
```

    Intensas lluvias provocaron esta noche desbordamiento de caudal del río Platanitos, afectó varios sectores de Villa… https://t.co/iLojQ3h7rg
    Intensas lluvias provocaron esta noche desbordamiento de caudal del río Platanitos, afectó varios sectores de Villa… https://t.co/5zZ0jYnlx6
    Intensas lluvias provocaron esta noche desbordamiento de caudal del río Platanitos, afectó varios sectores de Villa… https://t.co/7dycpwdBuG
    Intensas lluvias provocaron esta noche desbordamiento de caudal del río Platanitos, afectó varios sectores de Villa… https://t.co/tmfrhtgYc9
    San Miguel Petapa, Guatemala.
    
    Fuerte #LluviaGT afectó colonia Villa Hermosa.
    
    Reportan daños en banquetas, paredes… https://t.co/uDAEUYTYqZ
    Mt.6:34: Así que, no os afanéis por el día de mañana, porque cada día traerá su afán Hasta mañana con mas informaci… https://t.co/7881dsLEwS
    Y la #LluviaGt sigue en esta noche...
    #ClimaGt 
    #TraficoGT 
    #TransitoGt
    Deberían de salir ya para sus trabajos por el #TraficoGT 😬
    No importa jurisdicción de quien sea!!! K mal.. Al sur Aguilar Batres puente al cenma , PELIGROSO! n asfalto pelado… https://t.co/rMsrSXf82G
    Que paso en Campo Marte que está parado totalmente? @amilcarmontejo #TraficoGT @traficogt
    


```python
#minusculas
traffic_lower=[i.lower() for i in traffic_list]
sample_printer(traffic_lower)
```

    intensas lluvias provocaron esta noche desbordamiento de caudal del río platanitos, afectó varios sectores de villa… https://t.co/ilojq3h7rg
    intensas lluvias provocaron esta noche desbordamiento de caudal del río platanitos, afectó varios sectores de villa… https://t.co/5zz0jynlx6
    intensas lluvias provocaron esta noche desbordamiento de caudal del río platanitos, afectó varios sectores de villa… https://t.co/7dycpwdbug
    intensas lluvias provocaron esta noche desbordamiento de caudal del río platanitos, afectó varios sectores de villa… https://t.co/tmfrhtgyc9
    san miguel petapa, guatemala.
    
    fuerte #lluviagt afectó colonia villa hermosa.
    
    reportan daños en banquetas, paredes… https://t.co/udaeuytyqz
    mt.6:34: así que, no os afanéis por el día de mañana, porque cada día traerá su afán hasta mañana con mas informaci… https://t.co/7881dslews
    y la #lluviagt sigue en esta noche...
    #climagt 
    #traficogt 
    #transitogt
    deberían de salir ya para sus trabajos por el #traficogt 😬
    no importa jurisdicción de quien sea!!! k mal.. al sur aguilar batres puente al cenma , peligroso! n asfalto pelado… https://t.co/rmsrsxf82g
    que paso en campo marte que está parado totalmente? @amilcarmontejo #traficogt @traficogt
    

- Quitar los URL


```python
traffic_url=[re.sub('\w+:\/{2}[\d\w-]+(\.[\d\w-]+)*(?:(?:\/[^\s/]*))*','',i) for i in traffic_lower]
sample_printer(traffic_url)
```

    intensas lluvias provocaron esta noche desbordamiento de caudal del río platanitos, afectó varios sectores de villa… 
    intensas lluvias provocaron esta noche desbordamiento de caudal del río platanitos, afectó varios sectores de villa… 
    intensas lluvias provocaron esta noche desbordamiento de caudal del río platanitos, afectó varios sectores de villa… 
    intensas lluvias provocaron esta noche desbordamiento de caudal del río platanitos, afectó varios sectores de villa… 
    san miguel petapa, guatemala.
    
    fuerte #lluviagt afectó colonia villa hermosa.
    
    reportan daños en banquetas, paredes… 
    mt.6:34: así que, no os afanéis por el día de mañana, porque cada día traerá su afán hasta mañana con mas informaci… 
    y la #lluviagt sigue en esta noche...
    #climagt 
    #traficogt 
    #transitogt
    deberían de salir ya para sus trabajos por el #traficogt 😬
    no importa jurisdicción de quien sea!!! k mal.. al sur aguilar batres puente al cenma , peligroso! n asfalto pelado… 
    que paso en campo marte que está parado totalmente? @amilcarmontejo #traficogt @traficogt
    

- Quitar Caracteres especiales y Emojis


```python
traffic_special=[re.sub('[^a-zA-Z0-9 ]+','', i) for i in traffic_url]
sample_printer(traffic_special)
```

    intensas lluvias provocaron esta noche desbordamiento de caudal del ro platanitos afect varios sectores de villa 
    intensas lluvias provocaron esta noche desbordamiento de caudal del ro platanitos afect varios sectores de villa 
    intensas lluvias provocaron esta noche desbordamiento de caudal del ro platanitos afect varios sectores de villa 
    intensas lluvias provocaron esta noche desbordamiento de caudal del ro platanitos afect varios sectores de villa 
    san miguel petapa guatemalafuerte lluviagt afect colonia villa hermosareportan daos en banquetas paredes 
    mt634 as que no os afanis por el da de maana porque cada da traer su afn hasta maana con mas informaci 
    y la lluviagt sigue en esta nocheclimagt traficogt transitogt
    deberan de salir ya para sus trabajos por el traficogt 
    no importa jurisdiccin de quien sea k mal al sur aguilar batres puente al cenma  peligroso n asfalto pelado 
    que paso en campo marte que est parado totalmente amilcarmontejo traficogt traficogt
    

- Eliminación de Stopwords y abreviaturas comúnes


```python
stopwords=set(stopwords.words('spanish'))
special_words=['traficogt','transitogt','trficogt','trnsitogt','da','rbol']
for i in special_words:
    stopwords.add(i)

```


```python
traffic_clean=[]

# Revisar las palabras en cada oracion

for tweet in traffic_special:
    word_list=[]
    for word in tweet.split():
        if word not in stopwords:
            word_list.append(word)
    traffic_clean.append(' '.join(word_list))

sample_printer(traffic_clean)
```

    intensas lluvias provocaron noche desbordamiento caudal ro platanitos afect varios sectores villa
    intensas lluvias provocaron noche desbordamiento caudal ro platanitos afect varios sectores villa
    intensas lluvias provocaron noche desbordamiento caudal ro platanitos afect varios sectores villa
    intensas lluvias provocaron noche desbordamiento caudal ro platanitos afect varios sectores villa
    san miguel petapa guatemalafuerte lluviagt afect colonia villa hermosareportan daos banquetas paredes
    mt634 as afanis maana cada traer afn maana mas informaci
    lluviagt sigue nocheclimagt
    deberan salir trabajos
    importa jurisdiccin k mal sur aguilar batres puente cenma peligroso n asfalto pelado
    paso campo marte est parado totalmente amilcarmontejo
    

### Analisis Exploratorio

**3. Frecuencia de palabras**


```python
tweet_frequency=Counter()

for tweet in traffic_clean:
  tweet_frequency.update(palabra.strip('.,?!"\'').lower() for palabra in tweet.split())

frequency_frame= pd.DataFrame.from_dict(tweet_frequency, orient='index').reset_index()
frequency_frame=frequency_frame.rename(columns={"index":"palabra",0:"frecuencia"})

frequency_frame.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>palabra</th>
      <th>frecuencia</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>intensas</td>
      <td>8</td>
    </tr>
    <tr>
      <th>1</th>
      <td>lluvias</td>
      <td>13</td>
    </tr>
    <tr>
      <th>2</th>
      <td>provocaron</td>
      <td>4</td>
    </tr>
    <tr>
      <th>3</th>
      <td>noche</td>
      <td>11</td>
    </tr>
    <tr>
      <th>4</th>
      <td>desbordamiento</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>



**4. Palabras más Repetidas**


```python
frequency_frame.sort_values(by=['frecuencia'],ascending=False).head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>palabra</th>
      <th>frecuencia</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>162</th>
      <td>zona</td>
      <td>144</td>
    </tr>
    <tr>
      <th>190</th>
      <td>ruta</td>
      <td>116</td>
    </tr>
    <tr>
      <th>188</th>
      <td>km</td>
      <td>103</td>
    </tr>
    <tr>
      <th>183</th>
      <td>calle</td>
      <td>89</td>
    </tr>
    <tr>
      <th>150</th>
      <td>avenida</td>
      <td>81</td>
    </tr>
  </tbody>
</table>
</div>



**5. Word Cloud**


```python
wc = WordCloud(background_color="white",width=1000,height=1000, max_words=20,relative_scaling=0.5,normalize_plurals=False).generate_from_frequencies(tweet_frequency)
plt.imshow(wc)
```




    <matplotlib.image.AxesImage at 0x7f0f0ed62e80>




![png](output_27_1.png)


En base al word cloud se puede notar que los tuits tienen mucha informacion acerca del trafico, y no tanto opinion del mismo. Existe muchos termines como "zona","km","ruta" que son terminos que no reflejan opinion al resepecto. Al igual que muchas personas usan el nombre amilcarmontejo, para reportar de zonas de trafico en el area de las mismas.


```python
ordered_frame=frequency_frame.sort_values(by=['frecuencia'],ascending=False)

sliced_frame=ordered_frame[:15]

top_fifteen=sns.barplot(data=sliced_frame,x='palabra',y='frecuencia')

top_fifteen.set_xticklabels(top_fifteen.get_xticklabels(), rotation=90)

```




    [Text(0, 0, 'zona'),
     Text(0, 0, 'ruta'),
     Text(0, 0, 'km'),
     Text(0, 0, 'calle'),
     Text(0, 0, 'avenida'),
     Text(0, 0, 'san'),
     Text(0, 0, 'hacia'),
     Text(0, 0, 'calzada'),
     Text(0, 0, 'accidente'),
     Text(0, 0, 'guatemala'),
     Text(0, 0, 'amilcarmontejo'),
     Text(0, 0, 'reporta'),
     Text(0, 0, 'precaucin'),
     Text(0, 0, 'bulevar'),
     Text(0, 0, 'paso')]




![png](output_29_1.png)



```python
information_word=['zona','km','calle','calzada','bulevar','ruta','avenida','amilcarmontejo']
without_information=frequency_frame[~frequency_frame.palabra.isin(information_word)]


order_without=without_information.sort_values(by=['frecuencia'],ascending=False)

new_sliced=order_without[:15]

top_without=sns.barplot(data=new_sliced,x='palabra',y='frecuencia')

top_without.set_xticklabels(top_without.get_xticklabels(), rotation=90)
```




    [Text(0, 0, 'san'),
     Text(0, 0, 'hacia'),
     Text(0, 0, 'guatemala'),
     Text(0, 0, 'accidente'),
     Text(0, 0, 'reporta'),
     Text(0, 0, 'precaucin'),
     Text(0, 0, 'paso'),
     Text(0, 0, 'ciudad'),
     Text(0, 0, 'ahora'),
     Text(0, 0, 'mas'),
     Text(0, 0, 'lento'),
     Text(0, 0, 'pacfico'),
     Text(0, 0, 'villa'),
     Text(0, 0, 'atlntico'),
     Text(0, 0, '12')]




![png](output_30_1.png)


A continuacion se realiza un analisis por grupos de palabras relacionadas con rutas, de manera que se pueda tener visibilidad en cuales rutas son las mas reportadas con trafico.
Primero se obtendra las oraciones que tengan las palabras constantes que se desea indagar un poco mas. Segun los resultados previos son: "san","bulevar","zona" y "km"


```python
san_list=[]
bulevar=[]
zona=[]
km=[]

for i in traffic_clean:
  for j in i.split():
    count=0
    count=+1
    if(j=='san'):
      san_list.append(i)
    if(j=='bulevar'):
      bulevar.append(i)
    if(j=='zona'):
      zona.append(i)
    if(j=='km'):
      km.append(i)

```


```python
sample_printer(san_list)
```

    san miguel petapa guatemalafuerte lluviagt afect colonia villa hermosareportan daos banquetas paredes
    buenas noches pedimos patrulla urgente vale zempoala 36 casi esquina san borja col independencia
    nomsviolencia mpguatemala trabaja escena ataque armado 7 avenida calzada san jua
    bachejueputa guatemala noprospera acaba hacer shot carro bueno llanta 9calle 5ta av san
    choque heridos anillo periferico san juan amilcarmontejo ciudadpmt
    altura peri roosevelt lado calzada san juan personas tirando grasa holln l
    camin volteo averiadoruta pacfico amatitlnkm 255 prximo ingreso san jorgeobstaculiza medio
    est dificil pasar san lucas cola est mirador
    trnsito comprado examen licencia sepan manejar semana san
    inicia llegar mirador san lucassaleantiguazo
    


```python
sample_printer(bulevar)
```

    lluviagtafecta reas zona 1 2 5 6 7 10 15 16 17 18precaucin calzada paz bulevar
    transitogtvehculo neumtico pinchado bulevar asuncin zona 5
    puente asuncincarro neumtico pinchado bulevar asuncin zona 5 7 calle final
    transitogtcamioneta agrcola averiada bulevar vista hermosa
    pasajero microbs fallece tras ataque armado bulevar liberacin 13 calle zona 9via
    pasajero microbs fallece tras ataque armado bulevar liberacin 13 calle zona 9otro pasajero
    ultimominutogtpasajero microbs fallece tras ataque armado bulevar liberacin 13 calle zona
    sucesos fallecido dentro microbs deja ataque armado bulevar liberacin 13 calle zo
    nomsviolencia persona muere resulta herida luego ataque armado bulevar liberacin zo
    precaucin paso desnivel pap francisco bulevar prceres 27 avenida zona10 cerrado momentne
    


```python
sample_printer(zona)
```

    traficogtun fuerte accidente trnsito dej dos personas fallecidas zona 12 capital
    taxi colisiona pared negocio ubicado 2 avenida 9 calle zona 1 deja
    pared2 avenida 9 calle zona 1 taxi choca negocio herido auxiliado lugarprecauci
    queda habilitada calzada atanasio tzul 31 calle zona 12durante madrugada vehculo impact cont
    queda habilitada calzada atanasio tzul 31 calle zona 12durante madrugada vehculo impact contr
    queda habilitada nuevamente calzada atanasio tzul 31 calle zona 12 tras aparatoso accid
    queda habilitada calzada atanasio tzul 31 calle zona 12durante madrugada vehculo impact cont
    madrugada ocurri aparatoso accidente calzada atanasio tzul 31 calle zona 12 ca
    carro incendi calzada aguilar batres 32 calle zona 11no heridos segn bomberos ini
    lluviagtafecta reas zona 1 2 5 6 7 10 15 16 17 18precaucin calzada paz bulevar
    


```python
sample_printer(km)
```

    precaucin personas dirigen sur norte reportan km 32 ruta pacfic
    precaucinen ruta atlntico km 6 km 75 zona 17 avanza desfile escolar carril derec
    precaucinen ruta atlntico km 6 km 75 zona 17 avanza desfile escolar carril derec
    vehculo diriga sur derrib poste alumbrado pblico cay km 14 pacfico hac
    reporta accidente km 14 ruta pacfico precaucin lugar
    frenemoslosaccidentes precaucin km 14 ruta pacfico accidente res
    precaucin accidente km 14 5 ruta pacficovehculo derriba poste energa elctrica
    trailer colisiona separadores viales km 125 ruta salvador afectando ambas vasusuario
    trailer colisiona separadores viales km 125 ruta salvador afectando ambas vasusuario
    fuerte accidente km 39 carretera interamericana carril hacia ciudad guatemala
    

A continuacion creamos tablas de frecuencias para cada uno de las nuevas funtes de datos ya que queremos saber que palabras son las mas repetidas en estos casos. Se quito las palabras clavles mencionadas previamente ya que no queriamos que afectaran la frecuencia de las otras


```python
def cleaner(word,list_sentences):
  no_word=['san']
  no_word.append(word)
  new_list=[]
  for tweet in list_sentences:
      word_list=[]
      for word in tweet.split():
          if word not in no_word:
              word_list.append(word)
      new_list.append(' '.join(word_list))
  print(new_list)
  return new_list
san_removes=cleaner('san',san_list)
bulevar_removes=cleaner("bulevar",bulevar)
zona_removes=cleaner("zona",zona)
km_removes=cleaner("km",km)

print(san_removes)

san_frequency=Counter()

for tweet in san_removes:
  san_frequency.update(palabra.strip('.,?!"\'').lower() for palabra in tweet.split())

bulevar_frequency=Counter()

for tweet in bulevar_removes:
  bulevar_frequency.update(palabra.strip('.,?!"\'').lower() for palabra in tweet.split())

zona_frequency=Counter()

for tweet in zona_removes:
  zona_frequency.update(palabra.strip('.,?!"\'').lower() for palabra in tweet.split())

km_frequency=Counter()

for tweet in km_removes:
  km_frequency.update(palabra.strip('.,?!"\'').lower() for palabra in tweet.split())


```

    ['miguel petapa guatemalafuerte lluviagt afect colonia villa hermosareportan daos banquetas paredes', 'buenas noches pedimos patrulla urgente vale zempoala 36 casi esquina borja col independencia', 'nomsviolencia mpguatemala trabaja escena ataque armado 7 avenida calzada jua', 'bachejueputa guatemala noprospera acaba hacer shot carro bueno llanta 9calle 5ta av', 'choque heridos anillo periferico juan amilcarmontejo ciudadpmt', 'altura peri roosevelt lado calzada juan personas tirando grasa holln l', 'camin volteo averiadoruta pacfico amatitlnkm 255 prximo ingreso jorgeobstaculiza medio', 'est dificil pasar lucas cola est mirador', 'trnsito comprado examen licencia sepan manejar semana', 'inicia llegar mirador lucassaleantiguazo', 'trnsitogtamilcar montejo reporta ataque armado motorista calzada juan', 'disparan motorista calzada juan km 145 mixcoen intento evitar ser baleado intent llegar', 'disparan motorista calzada juan km 145 mixcoen intento evitar ser baleado intent llegar', 'disparan motorista calzada juan km 145 mixco reporta amilcarmontejo', 'disparan motorista calzada juan km 145 mixcoen intento evitar ser baleado intent llegar', 'nomsviolencia disparan motorista calzada juan km 145 mixco reporta amilcarmontejo', 'reportan complicaciones trnsito aguilar batres colisin registr calzada juan', 'manifestantes bloquean entrada col rafael ruta atlntico km 78 zona 17 zona 18segn', 'manifestantes bloquean entrada colonia rafael ruta atlntico km 78 zona 17 zona 18af', 'urgente manifestantes bloquean entrada col rafael ruta atlntico km 78 zona 17 zona', 'manifestantes bloquean entrada colonia rafael ruta atlntico km 78 zona 17 zona 18af', 'manifestantes bloquean entrada col rafael ruta atlntico km 78 zona 17 zona 18afecta', 'manifestantes bloquean entrada col rafael ruta atlntico km 78 zona 17 zona 18 segn', 'manifestantes bloquean entrada colonia rafael ruta atlntico km 78 zona 17 zona', 'urgente manifestantes bloquean entrada colonia rafael ruta atlntico km 78 zona 17', 'manifestacion manifestantes bloquean entrada col rafael ruta atlntico km 78 zona 17', 'ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78 zona 17', 'deborapirir ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78', 'fabyceal ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78', 'johannmarroqui2 ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78', 'cabreradjnq ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78', 'rogr1717 ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78', '10luzk ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78', 'bloqueo ingreso rafael z17 manifestacin', 'santosdalia munivillanueva favor poner orden 6 avenida jos das atrs', 'climagt derrumbe km 1155 ruta andrs semetabaj hacia panajachel solol bloqueado v', 'climagt conredguatemalareporta derrumbe km 1155 ruta andrs semetabaj hacia panajachel solol', 'derrumbekm 1155 rn1sol03 ruta andrs semetabaj panajachel paso momentos', 'emixtrapablo favor solicito revisen tiempos polica est bajo paso desnivel cri', 'queda habilitado carril reversible ruta salvador km 13 jos pinula fraijanesmejora', 'derrumbe km 24 carretera interamericana hacia lucas provoca lento salida cristbal', 'derrumbe km 24 carretera interamericana hacia lucas provoca lento salida cristbal', 'detenido km 23 ruta interamericana hacia lucas va jleonpl', 'usen roosevelt atascada accidente cris creo', 'breve cerrar ruta salvador kilmetro 12 complicado hacia jos pinula tomar va', 'ahora cerrado carril altura kilmetro 125 ruta salvador direccin jos pinula c', 'ahora bloquea km 91 carretera antigua conduce masagua hacia puerto jos', 'ahora bloquea km 91 carretera antigua conduce masagua hacia puerto jos', 'anoche bvoluntariosgt cristbal totonicapn informaron deslizamientos ruta interamer', 'ahora civguate reporta derrumbe carretera km 1515 rn1102 agua escondida desvo lucas tolimn solol', 'conredguatemala actualizacin personal emixtra trabaja km 24 carretera interamericana hacia lucas', 'ahora personal munimixco trabaja retirar bloquea jorge yumar zon', 'alerta vial cado puente monjitas bulevar isidro zona16 boquea pasopersonal limpia', 'ahora derrumbe km 24 ruta interamericana hacia lucas carril bloqueado va conredguatemala', 'ahora conredguatemala reporta derrumbe km 24 ruta interamericana hacia lucas carril bloqueado', 'amigues carreteras estn complicadas mucha lluvia neblina justo llegar cc puertas luc', 'puerto jos guatemala reporta tarde noche problemas calles avenidas principales desastresgt', 'puerto jos guatemala reporta tarde noche problemas calles avenidas principales desastresgt', 'nomsviolencia motorista muere luego ataque armado 32 avenida calzada juan inicia cierre', 'ataque armadofallece motorista mltiples disparos calzada juan 32 avenida zona 7inicio', 'ms dos horas trnsito an falta llegar destino as calzada juan buen', 'trfico lento calzada juan zona 7 amilcarmontejo', 'paso vial complicado salida granjas hacia bulevar principal ciudad cristbal zona 8 d', 'reporta accidente vial salida jorge muxbal vehculo cay barranco po', 'ms pesado trfico cristbal pesar colegios estn saliendo vacaciones pue', 'lluvia pertinaz descenso 4 5 grados debajo medias puerto jos reporta 3 horas lluvia', 'lluvia pertinaz descenso 4 5 grados debajo medias puerto jos reporta 3 horas lluvia', 'tras alerta posible atraco calzada juan 29 avenida zona 7 autoridades mantienen operativos calzada', 'tras alerta posible atraco calzada juan 29 avenida zona 7 autoridades mantienen operativos calzada', 'transitogtvehculo cae barranco km 64 ruta martn jilotepeque', 'paso liberado 1145 amruta pacfico suchitepquezkm 1495 circunvalacin antoniomanifestantes', 'pobladores mantienen bloqueo ruta pacfico jurisdiccin antonio suchitepquez l', 'frenemoslosaccidentes colisin vehicular 3 avenida 8 calle bulevar principal cristbal hacia', 'ahora est bloqueado km 1495 ca2 municipio antonio suchitepquez', 'lucas nuevo chimaltenango mierda cola guatemala']
    ['lluviagtafecta reas zona 1 2 5 6 7 10 15 16 17 18precaucin calzada paz', 'transitogtvehculo neumtico pinchado asuncin zona 5', 'puente asuncincarro neumtico pinchado asuncin zona 5 7 calle final', 'transitogtcamioneta agrcola averiada vista hermosa', 'pasajero microbs fallece tras ataque armado liberacin 13 calle zona 9via', 'pasajero microbs fallece tras ataque armado liberacin 13 calle zona 9otro pasajero', 'ultimominutogtpasajero microbs fallece tras ataque armado liberacin 13 calle zona', 'sucesos fallecido dentro microbs deja ataque armado liberacin 13 calle zo', 'nomsviolencia persona muere resulta herida luego ataque armado liberacin zo', 'precaucin paso desnivel pap francisco prceres 27 avenida zona10 cerrado momentne', 'ojodellector transurbano bloquea asuncin zona 5 hacia zona 1 va jsam202', 'bloqueadorbol cay conexin vial puente monjitas antiguo destacamento militar acatan', 'ahora bloquea conexin puente monjitas antiguo destacamento militar ac', 'bloqueadorbol cay conexin vial puente monjitas antiguo destacamento militar acatan', 'alerta vial cado puente monjitas isidro zona16 boquea pasopersonal limpia', 'prceres vista hermosa lento desplom ruta salvador', 'prceres vista hermosa lento desplom ruta salvador', 'prceres vista hermosa lento desplom ruta salvador', 'prceres vista hermosa lento desplom ruta salvador', 'transitogtcolisin vehculo motocicleta lndivar', 'motorista trasladado hospitalcolisin vehculo motocicleta landvar 11 calle zona', 'guatereporta maneja precaucin ten paciencia lento naranjo hacia', 'ojodellector lento naranjo hacia perifrico maneje precaucin', 'autoridades trnsito habilitan paso vehicular naranjo hacia capital', 'ojodellector autoridades habilitan paso vehicular naranjo hacia capital re', 'ahora liberan va naranjo cerrada cado conduzca preca', 'ojodellector tome cuenta naranjo ramas bloquean dos carri', 'paso vial complicado salida granjas hacia principal ciudad cristbal zona 8 d', 'ahora conredguatemala informa trabajadores retiran ramas bloquea dos carriles', 'cado naranjo salida madeiras', 'derrumbe grandes proporciones dificulta paso naranjo hacia anillo perif', 'frenemoslosaccidentes colisin vehicular 3 avenida 8 calle principal cristbal hacia', 'frenemoslosaccidentes emixtrapablo reporta colisin vehicular 3 avenida 8 calle principal sa', 'frenemoslosaccidentes emixtrapablo reporta accidente 3 calle 17 avenida pr']
    ['traficogtun fuerte accidente trnsito dej dos personas fallecidas 12 capital', 'taxi colisiona pared negocio ubicado 2 avenida 9 calle 1 deja', 'pared2 avenida 9 calle 1 taxi choca negocio herido auxiliado lugarprecauci', 'queda habilitada calzada atanasio tzul 31 calle 12durante madrugada vehculo impact cont', 'queda habilitada calzada atanasio tzul 31 calle 12durante madrugada vehculo impact contr', 'queda habilitada nuevamente calzada atanasio tzul 31 calle 12 tras aparatoso accid', 'queda habilitada calzada atanasio tzul 31 calle 12durante madrugada vehculo impact cont', 'madrugada ocurri aparatoso accidente calzada atanasio tzul 31 calle 12 ca', 'carro incendi calzada aguilar batres 32 calle 11no heridos segn bomberos ini', 'lluviagtafecta reas 1 2 5 6 7 10 15 16 17 18precaucin calzada paz bulevar', 'carro incendi calzada aguilar batres 32 calle 11no heridos segn bomberos ini', '20octubre19locucineccusacmarcha recorre 6ta av 1 ciudad capital tmelo cuenta', 'diadelarevoluciongtmarcha 20 octubre avanza avenida bolivar 40 29 calle 8se diri', 'marcha revolucin dirige 8 capitalina hacia plaza constitucin', 'diadelarevoluciongtmarcha 20 octubre avanza avenida bolivar 40 29 calle 8se diri', 'realizan trabajos mantenimiento columpio vista hermosa ambos 2 calle 10 avenida', 'precaucinen ruta atlntico km 6 km 75 17 avanza desfile escolar carril derec', 'trabajador fallecido gasolinera montufar 9 qepd amilcarmontejo', 'autobs extraurbano fallas mecnicas 7 avenida 250 9adelmo cardona informa coordina', 'ataque armado reportan hombre fallecido dentro rea privada calle montfar 0 avenida', 'ataque armado reportan hombre fallecido dentro rea privada calle montfar 0 avenida', 'ataque armado9 avenida 15 calle colonia verbena 7 hombre fallecio banqueta minist', 'amilcarmontejo posible pasar 5 avenida 6 avenida 2 calle 9 tome 45 minutos', 'vapulearon hombre perifrico sur puente incienso 3reportan transentes', 'dejan semirremolque estanque v cruzado ruta atlntico km 16 25afecta usuarios q', 'vapulearon hombre perifrico sur puente incienso 3reportan transentes', 'vapulearon hombre perifrico sur puente incienso 3reportan transentes', 'vapulearon hombre perifrico sur puente incienso 3reportan transentes', 'dejan semirremolque estanque v cruzado ruta atlntico km 16 25afecta usuarios q', 'transitogtvehculo neumtico pinchado bulevar asuncin 5', 'puente asuncincarro neumtico pinchado bulevar asuncin 5 7 calle final', 'trnsitogtconductor posiblemente ebrio interrumpi trnsito 1', 'dormidoconductor taxi inscrito chinautla detuvo carro avenida bolivar 25 calle 1', 'manifestacin frente procuradura derechos humanos 12 ave 13 calle 1 evite pasar ah', 'autobs fallas mecnicas 14 avenida 845 1usuarios provienen mercado coln bule', 'mismsimo don vergas estorbando 9a calle 1 amilcarmontejo', 'amilcarmontejo reporta autobs fallas mecnicas 14 avenida 8 calle 1', 'autobs fallas mecnicas 14 avenida 845 1usuarios provienen mercado coln bule', 'manifestantes bloquean entrada col rafael ruta atlntico km 78 17 18segn', 'manifestantes bloquean entrada col rafael ruta atlntico km 78 17 18segn', 'manifestantes bloquean entrada colonia rafael ruta atlntico km 78 17 18af', 'manifestantes bloquean entrada colonia rafael ruta atlntico km 78 17 18af', 'urgente manifestantes bloquean entrada col rafael ruta atlntico km 78 17', 'urgente manifestantes bloquean entrada col rafael ruta atlntico km 78 17', 'manifestantes bloquean entrada colonia rafael ruta atlntico km 78 17 18af', 'manifestantes bloquean entrada colonia rafael ruta atlntico km 78 17 18af', 'manifestantes bloquean entrada col rafael ruta atlntico km 78 17 18afecta', 'manifestantes bloquean entrada col rafael ruta atlntico km 78 17 18afecta', 'p tas pas 10', 'manifestantes bloquean entrada col rafael ruta atlntico km 78 17 18 segn', 'manifestantes bloquean entrada col rafael ruta atlntico km 78 17 18 segn', 'manifestantes bloquean entrada colonia rafael ruta atlntico km 78 17', 'manifestantes bloquean entrada colonia rafael ruta atlntico km 78 17', 'urgente manifestantes bloquean entrada colonia rafael ruta atlntico km 78 17', 'manifestacion manifestantes bloquean entrada col rafael ruta atlntico km 78 17', 'ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78 17', 'camioneta agrcola averiadabulevar vista hermosa 14 avenida 15pmtguatemala coordin retiro', 'camioneta agrcola averiadabulevar vista hermosa 14 avenida 15informa eduardo m coor', 'trnsitogtrboles punto caer talados sector 10', 'precaucin accidente 3a calle 5a avenida 1 municipio coatepeque', 'seora atropellada 10 calle 6 avenida 9bomberos municipales realizaron traslado centro', 'pradera concepcin est colapsado ayuda dnde voy ir 15', 'trnsitogtreportan percances viales ruta pacfico 10 ciudad', 'colisin dos automotores 6 avenida 9 calle 10segn reporte juan acajabon herid', 'colisin dos automotores 6 avenida 9 calle 10segn reporte juan acajabon herid', 'ahora bloqueado manifestacin 12 avenida 12 calle 1 va amilcarmontejo', 'ahora amilcarmontejo reporta bloqueado manifestacin 12 avenida 12 calle 1', 'trnsitogtprecaucin manifestacin obstruye paso sector 1', 'manifestaciongtbloquea paso 12 avenida 12 calle 1vehiculos desviados 10 calle 11', 'manifestaciongtbloquea paso 12 avenida 12 calle 1vehiculos desviados 10 calle 11', 'usuarios 15 10 circulan lento rumbo pinulasrealizan limpieza derrumbes ocurridos', 'usuarios 15 10 circulan lento rumbo pinulasrealizan limpieza derrumbes ocurridos', 'transitogtpanorama trnsito 19 avenida calle rodolfo robles 1 3henrypopa', 'carro volcado15 avenida 24 calle 6 reportan seal derribadamotor automv', 'pasajero microbs fallece tras ataque armado bulevar liberacin 13 calle 9via', 'pasajero microbs fallece tras ataque armado bulevar liberacin 13 calle 9otro pasajero', 'ultimominutogtpasajero microbs fallece tras ataque armado bulevar liberacin 13 calle', 'peatn atropellado 20 calle calzada aguilar batres 5 avenida 11informa selvin barrio', '12 avenida 10 abnerfigueroa', 'trnsitogteegsa contina desarrollando trabajos rea monjitas 16 registr cada', 'mientras 10 14 climagt lluviagt', 'reportan percance vial 9 personal municipal contina trabajando retirar zo', 'guatemala precaucinvial ciudad capital colisin7 avenida 1 calle 9 iniciaron maniobras', 'colisin7 avenida 1 calle 9informa delcid390 iniciaron maniobras habilitar', 'ojodellector transurbano bloquea bulevar asuncin 5 hacia 1 va jsam202', 'ojodellector transurbano bloquea bulevar asuncin 5 hacia 1 va jsam202', 'ojodellector usuario jorge flores informa lento calzada paz hacia 5', 'picop impacta parabus construccin transmetroguate perifrico 14 calle 7inf', 'picop impacta parabus construccin transmetroguate perifrico 14 calle 7inf', 'peatn baleado calzada atanasio tzul 53 calle 12informan maleantes asaltaban cerca r', 'ataque armadofallece motorista mltiples disparos calzada juan 32 avenida 7inicio', 'catico 10 20 calle 30 mins detenido', 'motorista trasladado hospitalcolisin vehculo motocicleta bulevar landvar 11 calle', 'gente abusiva 12 calle 5 av 9 direccin blvd liberacin amilcarmontejo', 'trnsitogtemixtra reporta cado 6 mixco', 'asesinan vendedor panesataquearmadotena puesto 2 calle 4 avenida 9reportan grupo', 'carro vuelca 8 abuso velocidad asfalto mojadoel paso sector alrededor', 'ataque armadofallece vendedor panes 2 calle 4 avenida 9 reportan grupo transe', 'ataque armado35 avenida 2713 5 disparan tripulantes motocicleta hombre fall', 'precaucinaccidente 36 calle 8 avenida 8 amilcarmontejo', 'ataque armadofallece vendedor panes 2 calle 4 avenida 9 reportan grupo transe', 'dos vehculos colisionaron 8 avenida 35 calle 8reportan 3 tripulantes quedaron heridos', 'accidente 36 calle 8 avenida 8 amilcarmontejo', 'trfico lento calzada juan 7 amilcarmontejo', 'paso vial complicado salida granjas hacia bulevar principal ciudad cristbal 8 d', 'autobs derriba arbol 6 avenida 1314 calle 9pmtguatemala informa autobs adems ser', 'causas desconocidas autobs derriba 6a avenida 13 14 calle 9 moment', 'autobs derriba arbol 6 avenida 1314 calle 9segun reporte carlos jimnez autobs adems', 'cumple pronstico lluvia precaucin lluvia 19', 'tras alerta posible atraco calzada juan 29 avenida 7 autoridades mantienen operativos calzada', 'operativo policial calzada roosevelt km 15 3 mixcoalta demanda hacia mixco ms disminucin carriles', 'tras alerta posible atraco calzada juan 29 avenida 7 autoridades mantienen operativos calzada', 'transitogtataque armado kaminal juyu i 7', 'operativo policial calzada roosevelt km 15 3 mixcoalta demanda hacia mixco ms disminucin', 'medioambiente mantengamos limpia ciudad tareas limpieza realizaron coloni', 'ataque armado15 avenida 8 calle 6 disparan conductor busruta203piloto ileso seg', 'trnsitogtbomberos voluntarios atendieron personas crisis nerviosa tras ataque armado 6', 'trnsitogtprecaucin bomberos atienden incendio 6', 'incendiogt 12 avenida 10 calle 6 asentamiento prspero penados barriobomberos', 'incendio varias casas asentamiento prspero penados barrio 12 avenida 10 calle 6 ce', 'cudruple colisin colonia lavarreda 18tres vehculos tipo sedn camin repartidor be', 'ataque armado dej persona fallecida 5 colisin registr 18', 'ataque armado dej persona fallecida 5 colisin registr 18', 'cuatro vehculos colisionaron bajada colonia lavarreda 18reporta adn mijangos', 'frenemoslosaccidentes amilcarmontejo reporta colisin vehicular 1 avenida 3 calle 1 heridos', 'frenemoslosaccidentes colisin vehicular 1 avenida 3 calle 1 heridos va', 'poste destruidocolisin dos automotores 1 avenida 3 calle 1segn reporte lesio', 'nunca falta imbecil traficogtamilcarmontejo 10a avenida 7a calle 1', 'fuertes hechos viales dejaron daos materiales menos nueve heridos reportaron 9', 'amilcarmontejo semforo diagonal 6 prceres 10 cambia rojo', 'colision camioneta microbs 6 avenida 5 calle 9reportan cuatro tripulantes heridos ini', 'precaucin 4 avenida 11 12 calle 10 arbor caido amilcarmontejo', 'caido4 avenida 1112 calle 10 reportan heridos coordinado equipo limpieza municipali', 'ahora usuario joseestuardope2 reporta cado 4 avenida 11 calle 10trficogt', 'cuatro heridoscolision camioneta microbs 6 avenida 5 calle 9reporta daniel jurez q', 'frenemoslosaccidentes accidente 5 calle 6 avenida 9 cinco personas heridas va', 'frenemoslosaccidentes bomberosmuni reportan accidente 5 calle 6 avenida 9 cinco perso', 'envuelto sbanas dejaron cadaver perifrico norte abajo puente ruedita 3', 'envuelto sbanas dejaron cadaver perifrico norte abajo puente ruedita 3', 'motocicleta derrapa 20 calle 12 avenida 10pmtguatemala inici acciones habilitar', 'frenemoslosaccidentes motorista derrapa 20 calle 12 avenida 10 reporta amilcarmontejo', 'motocicleta derrapa 20 calle 12 avenida 10informa eddy samayoa iniciaron acciones h', 'reportan colisin 9 calle 3 avenida 10edwin camo informa conductores motocicleta ca', 'incendio declarado cartonera 3 cuerpos emergencia trabajan 4 horas desastresgt']
    ['precaucin personas dirigen sur norte reportan 32 ruta pacfic', 'precaucinen ruta atlntico 6 75 zona 17 avanza desfile escolar carril derec', 'precaucinen ruta atlntico 6 75 zona 17 avanza desfile escolar carril derec', 'vehculo diriga sur derrib poste alumbrado pblico cay 14 pacfico hac', 'reporta accidente 14 ruta pacfico precaucin lugar', 'frenemoslosaccidentes precaucin 14 ruta pacfico accidente res', 'precaucin accidente 14 5 ruta pacficovehculo derriba poste energa elctrica', 'trailer colisiona separadores viales 125 ruta salvador afectando ambas vasusuario', 'trailer colisiona separadores viales 125 ruta salvador afectando ambas vasusuario', 'fuerte accidente 39 carretera interamericana carril hacia ciudad guatemala', 'precaucin accidente trnsito 555 ca9', 'accidente 135 ruta interamericana deja muerto frenemoslosaccidentesva', 'frenemoslosaccidentes provial reporta persona muerta accidente 135 ruta', 'frenenemoslosaccidentes persona result herida accidente 55 ruta atln', 'dejan semirremolque estanque v cruzado ruta atlntico 16 zona 25afecta usuarios q', 'transitogtsemirremolque bloqueando carril 16 ruta atlntico', 'dejan semirremolque estanque v cruzado ruta atlntico 16 zona 25afecta usuarios q', 'trailer descompone 14 ruta atlantico tapando 2 carriles amilcarmontejo', 'correccin 60 carretera autopista paln escuintla accidente vial dao estructural carro tanque 2k gal', 'urgentegtemulsin asfltica derrama cisterna involucrado colisin transporte pesado 60', 'mltiple colisin transporte pesado 60 ruta pacfico afecta viajeros hacia sur', 'mltiple colisin transporte pesado 60 ruta pacfico afecta viajeros hacia sur', 'urgentemltiple colisin transporte pesado 60 ruta pacfico afecta viajeros hacia', 'mltiple colisin transporte pesado 60 ruta pacfico afecta escuintla', 'alertagtmltiple colisin transporte pesado 60 ruta pacfico afecta viajeros hac', 'urgenteaccidente dos triler 51 autopista paln escuintlaampliaremos', 'poca visibilidad 177 ruta interamericana niebla va provial', 'precaucin 177 ruta interamericana provial reporta poca visibilidad niebla', 'frenemoslosaccidentes vehculo particular camin chocaron 13 calzada roosevelt hacia mixc', 'frenemoslosaccidentes mujer resulta lesionada luego accidente 15 ruta', 'santosdalia registra accidente trnsito 15 ruta pacfico', 'santosdalia reporta fuerte accidente 15 ruta pacfico carriles co', 'disparan motorista calzada juan 145 mixcoen intento evitar ser baleado intent llegar', 'disparan motorista calzada juan 145 mixcoen intento evitar ser baleado intent llegar', 'disparan motorista calzada juan 145 mixco reporta amilcarmontejo', 'disparan motorista calzada juan 145 mixcoen intento evitar ser baleado intent llegar', 'nomsviolencia disparan motorista calzada juan 145 mixco reporta amilcarmontejo', 'manifestantes bloquean entrada col rafael ruta atlntico 78 zona 17 zona 18segn', 'manifestantes bloquean entrada colonia rafael ruta atlntico 78 zona 17 zona 18af', 'urgente manifestantes bloquean entrada col rafael ruta atlntico 78 zona 17 zona', 'manifestantes bloquean entrada colonia rafael ruta atlntico 78 zona 17 zona 18af', 'manifestantes bloquean entrada col rafael ruta atlntico 78 zona 17 zona 18afecta', 'manifestantes bloquean entrada col rafael ruta atlntico 78 zona 17 zona 18 segn', 'manifestantes bloquean entrada colonia rafael ruta atlntico 78 zona 17 zona', 'urgente manifestantes bloquean entrada colonia rafael ruta atlntico 78 zona 17', 'manifestacion manifestantes bloquean entrada col rafael ruta atlntico 78 zona 17', 'ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico 78 zona 17', 'deborapirir ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico 78', 'fabyceal ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico 78', 'johannmarroqui2 ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico 78', 'cabreradjnq ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico 78', 'rogr1717 ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico 78', '10luzk ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico 78', 'transitogtpresencia lluvia 152 ruta ca2 occidente', 'climagt derrumbe 1155 ruta andrs semetabaj hacia panajachel solol bloqueado v', 'climagt conredguatemalareporta derrumbe 1155 ruta andrs semetabaj hacia panajachel solol', 'frenemoslosaccidentes accidente 31 ruta pacfico hacia sur va provial', 'frenemoslosaccidentes provial reporta accidente 31 ruta pacfico hacia sur', 'transitogtbrigadas provial atienden hecho transito 52 ruta atlntico ca9 norte', 'queda habilitado carril reversible ruta salvador 13 jos pinula fraijanesmejora', 'derrumbe 24 carretera interamericana hacia lucas provoca lento salida cristbal', 'detenido 23 ruta interamericana hacia lucas va jleonpl', 'ahora habr cierre tramo 11 ruta salvador inform pmt guatemala', 'ahora pmt guatemala informa habr cierre tramo 11 ruta salvador', '12 carretera salvador direccin oriente partir 11 horas realizar cierre total cort', '24 carretera interamericana mixco pmts trabajan intentando habilitar agilizar pasos derrumbes', 'solola ruta interamericana ca1 jurisdiccin departamento 1165 170 reportan 14 derrumbes', 'ahora bloquea 91 carretera antigua conduce masagua hacia puerto jos', 'ahora bloquea 91 carretera antigua conduce masagua hacia puerto jos', 'ahora civguate reporta derrumbe carretera 1515 rn1102 agua escondida desvo lucas tolimn solol', 'frenemoslosaccidentes picop automvil colisionan 95 ruta conduce escuintla sacatepquez n', 'conredguatemala actualizacin personal munimixco retira piedras bloquean 24 carr', 'conredguatemala actualizacin personal emixtra trabaja 24 carretera interamericana hacia lucas', 'ahora derrumbe 24 ruta interamericana hacia lucas carril bloqueado va conredguatemala', 'ahora conredguatemala reporta derrumbe 24 ruta interamericana hacia lucas carril bloqueado', 'pmt trabaja habilitar acceso oriente carretera salvador 11 rboles obstruyen paso', 'carretera salvador obstruye paso ascenso altura 11 prudencia ahora paso cerrando direcci', 'tmeloencuentaurgente cado 35 entrada finca florencia ruta bloqueada tome prec', 'transitogtcolisin camin triler 1125 ruta verapaces', 'frenemoslosaccidentes vehculo pncdeguatemala vuelca 65 ruta pacfico reporta', 'rutaalpacficoprovial reporta percance vial 61 ruta pacfico ca9 sur', 'deslizamiento 121 carretera interamericana provial trabaja habitacin ruta largas colas direccin', 'ojodellector maneje despacio encienda luces vehculo lento 23 carretera interamer', 'empieza 24 ruta interamericana', 'as luce paso vehicular 9 ruta salvador', 'lento 15 ruta pacfico cuesta villalobos ciudad', 'transitogtextreme medidas precaucin reportan lluvia niebla 72 ruta interamericanaencienda', 'operativo policial calzada roosevelt 15 zona 3 mixcoalta demanda hacia mixco ms disminucin carriles', 'transitogtvehculo cae barranco 64 ruta martn jilotepeque', 'operativo policial calzada roosevelt 15 zona 3 mixcoalta demanda hacia mixco ms disminucin', 'villa nueva guatemalaretiran 7 vehculos colisionaron s 183 ruta pacfico afect', 'palencia guatemalacolisin automvil vehculo 25 ruta atlntico aldea azacu', 'trnsitogtemixtra reportacirculacin fluida 15 calzada roosevelt hacia guatemala pmt trab', 'frenemoslosaccidentes vehculo empotra bus extraurbano 25 carretera atlntico hacia orien', 'frenemoslosaccidentes vehculo empotra bus extraurbano 25 carretera atlntico hacia orien', 'vehculos involucrados accidente madrugada 185 ruta pacfico direccin hacia ciudad', 'frenemoslosaccidentes autoridades coordinan movilizacin vehculos involucrados choque', 'frenemoslosaccidentes paso vehculos complicado 18 ruta pacfico choque mltip', 'ahora est bloqueado 1495 ca2 municipio antonio suchitepquez', 'frenemoslosaccidentes autobs choc cuatro vehculos 18 ruta pacfico rumbo capita', 'frenemoslosaccidentes bus empresa esmeralda choca cuatro carros 18 ruta pacfico hacia', 'frenemoslosaccidentes santosdalia reporta bus empresa esmeralda choca cuatro carros 1', 'picop triler chocan 192 ruta reuxela seis personas resultan heridas leves']
    ['miguel petapa guatemalafuerte lluviagt afect colonia villa hermosareportan daos banquetas paredes', 'buenas noches pedimos patrulla urgente vale zempoala 36 casi esquina borja col independencia', 'nomsviolencia mpguatemala trabaja escena ataque armado 7 avenida calzada jua', 'bachejueputa guatemala noprospera acaba hacer shot carro bueno llanta 9calle 5ta av', 'choque heridos anillo periferico juan amilcarmontejo ciudadpmt', 'altura peri roosevelt lado calzada juan personas tirando grasa holln l', 'camin volteo averiadoruta pacfico amatitlnkm 255 prximo ingreso jorgeobstaculiza medio', 'est dificil pasar lucas cola est mirador', 'trnsito comprado examen licencia sepan manejar semana', 'inicia llegar mirador lucassaleantiguazo', 'trnsitogtamilcar montejo reporta ataque armado motorista calzada juan', 'disparan motorista calzada juan km 145 mixcoen intento evitar ser baleado intent llegar', 'disparan motorista calzada juan km 145 mixcoen intento evitar ser baleado intent llegar', 'disparan motorista calzada juan km 145 mixco reporta amilcarmontejo', 'disparan motorista calzada juan km 145 mixcoen intento evitar ser baleado intent llegar', 'nomsviolencia disparan motorista calzada juan km 145 mixco reporta amilcarmontejo', 'reportan complicaciones trnsito aguilar batres colisin registr calzada juan', 'manifestantes bloquean entrada col rafael ruta atlntico km 78 zona 17 zona 18segn', 'manifestantes bloquean entrada colonia rafael ruta atlntico km 78 zona 17 zona 18af', 'urgente manifestantes bloquean entrada col rafael ruta atlntico km 78 zona 17 zona', 'manifestantes bloquean entrada colonia rafael ruta atlntico km 78 zona 17 zona 18af', 'manifestantes bloquean entrada col rafael ruta atlntico km 78 zona 17 zona 18afecta', 'manifestantes bloquean entrada col rafael ruta atlntico km 78 zona 17 zona 18 segn', 'manifestantes bloquean entrada colonia rafael ruta atlntico km 78 zona 17 zona', 'urgente manifestantes bloquean entrada colonia rafael ruta atlntico km 78 zona 17', 'manifestacion manifestantes bloquean entrada col rafael ruta atlntico km 78 zona 17', 'ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78 zona 17', 'deborapirir ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78', 'fabyceal ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78', 'johannmarroqui2 ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78', 'cabreradjnq ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78', 'rogr1717 ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78', '10luzk ultimominutogtmanifestantes bloquean entrada col rafael ruta atlntico km 78', 'bloqueo ingreso rafael z17 manifestacin', 'santosdalia munivillanueva favor poner orden 6 avenida jos das atrs', 'climagt derrumbe km 1155 ruta andrs semetabaj hacia panajachel solol bloqueado v', 'climagt conredguatemalareporta derrumbe km 1155 ruta andrs semetabaj hacia panajachel solol', 'derrumbekm 1155 rn1sol03 ruta andrs semetabaj panajachel paso momentos', 'emixtrapablo favor solicito revisen tiempos polica est bajo paso desnivel cri', 'queda habilitado carril reversible ruta salvador km 13 jos pinula fraijanesmejora', 'derrumbe km 24 carretera interamericana hacia lucas provoca lento salida cristbal', 'derrumbe km 24 carretera interamericana hacia lucas provoca lento salida cristbal', 'detenido km 23 ruta interamericana hacia lucas va jleonpl', 'usen roosevelt atascada accidente cris creo', 'breve cerrar ruta salvador kilmetro 12 complicado hacia jos pinula tomar va', 'ahora cerrado carril altura kilmetro 125 ruta salvador direccin jos pinula c', 'ahora bloquea km 91 carretera antigua conduce masagua hacia puerto jos', 'ahora bloquea km 91 carretera antigua conduce masagua hacia puerto jos', 'anoche bvoluntariosgt cristbal totonicapn informaron deslizamientos ruta interamer', 'ahora civguate reporta derrumbe carretera km 1515 rn1102 agua escondida desvo lucas tolimn solol', 'conredguatemala actualizacin personal emixtra trabaja km 24 carretera interamericana hacia lucas', 'ahora personal munimixco trabaja retirar bloquea jorge yumar zon', 'alerta vial cado puente monjitas bulevar isidro zona16 boquea pasopersonal limpia', 'ahora derrumbe km 24 ruta interamericana hacia lucas carril bloqueado va conredguatemala', 'ahora conredguatemala reporta derrumbe km 24 ruta interamericana hacia lucas carril bloqueado', 'amigues carreteras estn complicadas mucha lluvia neblina justo llegar cc puertas luc', 'puerto jos guatemala reporta tarde noche problemas calles avenidas principales desastresgt', 'puerto jos guatemala reporta tarde noche problemas calles avenidas principales desastresgt', 'nomsviolencia motorista muere luego ataque armado 32 avenida calzada juan inicia cierre', 'ataque armadofallece motorista mltiples disparos calzada juan 32 avenida zona 7inicio', 'ms dos horas trnsito an falta llegar destino as calzada juan buen', 'trfico lento calzada juan zona 7 amilcarmontejo', 'paso vial complicado salida granjas hacia bulevar principal ciudad cristbal zona 8 d', 'reporta accidente vial salida jorge muxbal vehculo cay barranco po', 'ms pesado trfico cristbal pesar colegios estn saliendo vacaciones pue', 'lluvia pertinaz descenso 4 5 grados debajo medias puerto jos reporta 3 horas lluvia', 'lluvia pertinaz descenso 4 5 grados debajo medias puerto jos reporta 3 horas lluvia', 'tras alerta posible atraco calzada juan 29 avenida zona 7 autoridades mantienen operativos calzada', 'tras alerta posible atraco calzada juan 29 avenida zona 7 autoridades mantienen operativos calzada', 'transitogtvehculo cae barranco km 64 ruta martn jilotepeque', 'paso liberado 1145 amruta pacfico suchitepquezkm 1495 circunvalacin antoniomanifestantes', 'pobladores mantienen bloqueo ruta pacfico jurisdiccin antonio suchitepquez l', 'frenemoslosaccidentes colisin vehicular 3 avenida 8 calle bulevar principal cristbal hacia', 'ahora est bloqueado km 1495 ca2 municipio antonio suchitepquez', 'lucas nuevo chimaltenango mierda cola guatemala']
    


```python
ws = WordCloud(background_color="white",width=1000,height=1000, max_words=20,relative_scaling=0.5,normalize_plurals=False).generate_from_frequencies(san_frequency)
plt.imshow(ws)

```




    <matplotlib.image.AxesImage at 0x7f0f0ebe8940>




![png](output_39_1.png)



```python
wb = WordCloud(background_color="white",width=1000,height=1000, max_words=20,relative_scaling=0.5,normalize_plurals=False).generate_from_frequencies(bulevar_frequency)
plt.imshow(wb)

```




    <matplotlib.image.AxesImage at 0x7f0f0fc40748>




![png](output_40_1.png)



```python
wz = WordCloud(background_color="white",width=1000,height=1000, max_words=20,relative_scaling=0.5,normalize_plurals=False).generate_from_frequencies(zona_frequency)
plt.imshow(wz)

```




    <matplotlib.image.AxesImage at 0x7f0f0ea61ac8>




![png](output_41_1.png)



```python
wk = WordCloud(background_color="white",width=1000,height=1000, max_words=20,relative_scaling=0.5,normalize_plurals=False).generate_from_frequencies(km_frequency)
plt.imshow(wk)
```




    <matplotlib.image.AxesImage at 0x7f0f0ec4dcc0>




![png](output_42_1.png)


#### Descubrimientos encontrados

En base a los resultados obtenidos podemos encontrar cosas interesantes acerca del trafico en Guatemala. En primer lugar, y bastante evidente, es que la mayoria de los tuits realizados son mas para informar que para quejarse del mismo, esto se puede notar en las frecuencias de las palabras ya que la mayoria son palabras que describen una ubicacion o hablan de lo sucedido. Por otro lado, los accidentes son la causa mayoritaria por la cual se produce el trafico. Esto se puede notar a que se mantuvo constante en la mayoria de los analisis. Otras razones de trafico: bloqueos, manifestaciones y ataques armados, segun los resultados que obtuvimos. Por otro lado, las areas principales afectadas resultan siendo: vista hermosa, ruta hacia el atlantico, zona 1 y zona 10. Esto es notorio en los wordclouds realizados.

### Conclusiones



*   Gran parte de los tuits sobre el trafico en guatemala son informativos y no de opinion
*   La cuenta de tuiter "amilcarmontejo" es un claro constante y es notorio que mucha gente le envia informacion a el acerca del transito.
*   Las razones de transito mas comun son los accidentes
*   Vista hermosa y ruta del atlantico son las areas mas mencionadas con transito 


